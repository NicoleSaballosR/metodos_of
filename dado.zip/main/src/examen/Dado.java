package examen;

import java.util.Scanner;

public class Dado {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc= new Scanner(System.in);
		try { 
		
		int n, opc=0,op1;
		  System.out.println("Con el numero 0 puede iniciar el juego, SUERTE!");
		  n=tc.nextInt();
		  
		  if(n==0) {
			  opc= (int)(Math.random()*6);
			  if (opc==4) {
				  System.out.println("FELICIDADES!!, usted ha sido el ganador ;)\n"+opc);
			  }else {
				  System.out.println("LO SIENTO, siga participando ;( \n"+ opc);
			  }
			  }else {
				  System.out.println("Lo siento, no es el numero requerido para iniciar el juego");
		  }
	 
	
		} catch ( java.util.InputMismatchException e) {
			System.out.println("No puede ingresesar letras, ni caracteres");
		}
	}
}
