import clas.Factura;
import java.util.*;

import javax.swing.JOptionPane;

public class main_poo {

	public static void main(String[] args) {

		//para generar un factura primero hay que hacer una compra		
				boolean continuar = true;
				 Scanner sc = new Scanner(System.in);
				int opcion = 0;
				Factura f = new Factura();
				while(continuar) {
					f.Comprar();
					System.out.println("Desea realizar otra compra?");
					
					System.out.println("1.Si\n 2.NO");
					opcion = sc.nextInt();
					
					if(opcion != 1) {
						continuar = false;
					}
				}
				
				f.ObtenerFactura();
				


	}

}
