package clas;
import java.time.LocalDate;

public class Factura extends Compra{

private LocalDate fechaFactura;
	
	public Factura() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public LocalDate getFechaFactura() {
		return fechaFactura;
	}
	public void setFechaFactura(LocalDate fechaFactura) {
		this.fechaFactura = fechaFactura;
	}
	
	public void ObtenerFactura() {
		for (Factura item : facturas) {
			System.out.println("**************************************************");
				System.out.println("Factura#" + (facturas.indexOf(item)+1));
				
				System.out.println("************IMPRIMIENDO VOUCHER DE FACTURA!!*****************************");
				System.out.println("****************************************************");
				System.out.println("Producto: " + item.getProducto().getNombre()+"");
				System.out.println("Marca: " + item.getProducto().getMarca());
				System.out.println("Precio: " + item.getProducto().getPrecio());
				System.out.println("Categoria: " + item.getProducto().getCategoria());
				System.out.println("Fecha de la factura: " + item.getFechaFactura());
				System.out.println("Cantidad adquirida: " + item.getCantidad());
				System.out.println("Monto: "+(item.getProducto().getPrecio()*item.getCantidad())+"\n");
				System.out.println("*****************************************");
			
		}
	}
}
