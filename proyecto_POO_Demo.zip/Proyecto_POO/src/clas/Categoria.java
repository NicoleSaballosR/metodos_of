package clas;
import java.util.ArrayList;
public class Categoria {
	private ArrayList<String> categorias = new  ArrayList<String>();
	public Categoria() {		
		categorias.add("Televisores");
		categorias.add("Refrigeradoras");
		categorias.add("Cocinas");
		categorias.add("Lavado");
	}

	public ArrayList<String> getCategorias() {
		return categorias;
	}
}
