package clas;
import java.util.ArrayList;

public class Inventario {
	private ArrayList<String> inventario;

	public Inventario() {
		inventario = new ArrayList<String>();
		inventario.add("Lavadora");
		inventario.add("Refrigerador");
		inventario.add("Televisor");	
	}

	public ArrayList<String> getInventario() {
		return inventario;
	}
}
