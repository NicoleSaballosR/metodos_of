package clas;
import java.time.LocalDate;
import java.util.Scanner;
import java.util.ArrayList;

public class Compra {
	Scanner sc = new Scanner(System.in);

	private int Cantidad;
	private Inventario inventario;
	private Producto producto;
	ArrayList<Factura> facturas = new ArrayList<>();
	public Compra() {
		inventario = new Inventario();
		Cantidad = 0;
		producto = new Producto();
	}

	public int getCantidad() {
		return Cantidad;
	}

	public void setCantidad(int cantidad) {
		Cantidad = cantidad;
	}

	public Inventario getInventario() {
		return inventario;
	}

	public void setInventario(Inventario inventario) {
		this.inventario = inventario;
	}

	public Producto getProducto() {
		return producto;
	}

	public void setProducto(Producto producto) {
		this.producto = producto;
	}

	public void Comprar() {
		int producto;
		System.out.println("--------------------------");
		System.out.println("Productos en venta");
		System.out.println("--------------------------");
		for (String i : getInventario().getInventario()) {
			System.out.println("Producto #" + (getInventario().getInventario().indexOf(i) + 1) + " " + i);
		}
		System.out.println("Digite el numero del producto que desea adquirir");
		producto = sc.nextInt();

		switch (producto) {
		case 1:
			System.out.println("Cantidad ha adquirir");
			setCantidad(sc.nextInt());
			Producto p = new Producto();
			p.setNombre("Lavadora");
			p.setCategoria(p.getCategorias().get(3));
			p.setMarca("LG");
			p.setPrecio(15000);
			
			Factura f = new Factura();
			f.setFechaFactura(LocalDate.now());
			f.setCantidad(getCantidad());
			f.setProducto(p);			
						
			facturas.add(f);		
			break;
		case 2:
			System.out.println("Cantidad ha adquirir");
			setCantidad(sc.nextInt());
			Producto p2 = new Producto();
			p2.setNombre("Refrigeradora");
			p2.setCategoria(p2.getCategorias().get(1));
			p2.setMarca("LG");
			p2.setPrecio(17000);
			
			Factura F = new Factura();
			F.setFechaFactura(LocalDate.now());
			F.setCantidad(getCantidad());
			F.setProducto(p2);			
						
			facturas.add(F);
			break;
		case 3:
			System.out.println("Cantidad ha adquirir");
			setCantidad(sc.nextInt());
			Producto p3 = new Producto();
			p3.setNombre("Televisor");
			p3.setCategoria(p3.getCategorias().get(0));
			p3.setMarca("SAMSUNG");
			p3.setPrecio(8500);
			
			Factura FA = new Factura();
			FA.setFechaFactura(LocalDate.now());
			FA.setCantidad(getCantidad());
			FA.setProducto(p3);			
						
			facturas.add(FA);
			break;
		default:
			break;
		}

	}

}
