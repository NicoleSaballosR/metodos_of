package pruebaprueba;

import java.util.Scanner;

public class cuenta {

String titular;
double cantidad;
public cuenta(String titular, double cantidad) {
	super();
	this.titular = titular;
	this.cantidad = cantidad;
}
public String getTitular() {
	return titular;
}
public void setTitular(String titular) {
	this.titular = titular;
}
public double getCantidad() {
	return cantidad;
}
public void setCantidad(double cantidad) {
	this.cantidad = cantidad;
}
@Override
public String toString() {
	return "cuenta [titular=" + titular + ", cantidad=" + cantidad + "]";
}
Scanner tc= new Scanner(System.in); 
public void leerti() {
	System.out.println("Ingrese el nombre del titular");
	titular=tc.nextLine();
}
public void mostrar_tit() {
	System.out.println("El titular es : \n"+ titular);
}
public void leercantidad() {
	do {
	System.out.println("Ingrese el monto de la cuenta");
	cantidad= tc.nextDouble();
	if (cantidad <0){
	System.out.println("Ingrese una catidad positiva");	
	}
	} while (cantidad<0);
}
public void mostrar_can() {
	System.out.println("Usted tiene en su cuenta la cantidad de :\n"+cantidad);
}
double ingreso;
double retiro;
double total1;
double total2;

public double ingreso() {
	System.out.println("Qué monto desea agregar?");
	ingreso= tc.nextDouble();
	if(ingreso <0) {
		System.out.println("La cantidad de su cuenta es :\n"+ cantidad);
		System.exit(0);
	}
	if (ingreso>0) {
		total1= cantidad + ingreso;
		System.out.println("Su cuenta ahora esta en : \n"+total1);
	}
	return ingreso;
}
public double retiro() {
	System.out.println("Ingrese la cantidad que desee retirar");
	retiro = tc.nextDouble();
	if (retiro<0) {
		System.out.println("Su cuenta esta en 0");
		System.exit(0);
	}
	if (retiro>0) {
		total2= cantidad - retiro;
		System.out.println("Su cuenta quedo en :\n"+total2);
	}
	return retiro;
}



}
