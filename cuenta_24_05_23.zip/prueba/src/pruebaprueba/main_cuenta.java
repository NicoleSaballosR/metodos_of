package pruebaprueba;
import java.util.Scanner;

public class main_cuenta {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc= new Scanner(System.in);
		int opc ;
  cuenta cuent = new cuenta(null, 0);
  
  cuent.leerti();
  tc.nextLine();
  try {
  cuent.leercantidad();
cuent.mostrar_tit();
cuent.mostrar_can();


do {
	System.out.println("Que operación desea realizar \n 1- Ingreso de efectivo \n 2- Retiro \n 3- Salida");
	opc= tc.nextInt();
switch (opc) {
case 1 :
	cuent.ingreso();
	break;

	
case 2 : 
	cuent.retiro();
	break;

	
case 3: 
	System.out.println("Gracias por preferirnos :)");
	break;
default: System.out.println("Opción invalida");
break;
} 

	
}while (opc!=3);
	}catch ( java.util.InputMismatchException y) {
		System.out.println("SOLO SE PERMITEN NÚMEROS");
	}
	}
}
